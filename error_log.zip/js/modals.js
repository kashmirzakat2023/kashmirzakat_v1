function close_up() {
    // document.getElementById('signup').style.display = "none"; 
    $('#signup').modal('hide');

}
function close_in() {
    // document.getElementById('signin').style.display = "none"; 
    $('#signin').modal('hide');
}

