<?php
$db = mysqli_connect("localhost", "kashmivu_id_rsa", "Kashmirzakat@123", "kashmivu_db");
if (!$db) die('could not connect Mysql server');
?>