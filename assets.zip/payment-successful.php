<?php 
include 'assets/nav-links.php'; ?>
<html>
<!-- <link href="https://allfont.net/allfont.css?fonts=kaushan-script" rel="stylesheet" type="text/css" /> -->
<link rel="stylesheet" href="css/success.css">
<script src="js/success.js"></script>
<?php
include 'assets/navbar.php';
?>
<body>

    <center>
    <div class="card m-5 " style="height: 60vh; width:70%; box-shadow: rgba(0, 0, 0, 0.35) 0px 5px 15px;">
        <div class="card-body">
                <div class="check_mark">
                    <div class="sa-icon sa-success animate">
                        <span class="sa-line sa-tip animateSuccessTip"></span>
                        <span class="sa-line sa-long animateSuccessLong"></span>
                        <div class="sa-placeholder"></div>
                        <div class="sa-fix"></div>
                    </div>
                </div>
                <h1 class="card-title fw-bolder" style=" font-family:'Trebuchet MS', 'Lucida Sans Unicode', 'Lucida Grande', 'Lucida Sans', Arial, sans-serif; letter-spacing:4px;">Thank You</h1>
                <h5>Your donation has been received successfully, thanks for your support.</h5>
                <a class="btn btn-success mt-3 fs-4" href="index.php">Go to Home →</a>
            </div>
        </div>
    </center>
    <?php
include 'assets/footer.php';
?>
</body>

</html>